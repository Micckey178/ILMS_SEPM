import React, { useState, useEffect } from 'react';
import {
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
  Clock,
  Plus,
  Share2,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
  Download,
  Filter,
  Building2,
  Cpu,
  Layers,
  X,
  Search,
  RotateCcw,
  Tag,
  BookOpen,
  Wrench,
  Users
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { DataService } from '../services/dataService';
import { EquipmentBooking, PracticalSession, MaintenanceRecord } from '../types';

export const CalendarPage: React.FC = () => {
  const { activeLab, currentUser } = useAuth();
  const [currentDate, setCurrentDate] = useState(new Date());
  const [viewMode, setViewMode] = useState<'month' | 'week' | 'day' | 'agenda'>('month');
  const [bookings, setBookings] = useState<EquipmentBooking[]>([]);
  const [sessions, setSessions] = useState<PracticalSession[]>([]);
  const [maintenances, setMaintenances] = useState<MaintenanceRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedEvent, setSelectedEvent] = useState<any>(null);

  // Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDiscipline, setSelectedDiscipline] = useState<string>('ALL');
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');
  const [selectedEventType, setSelectedEventType] = useState<string>('ALL');

  const disciplines = [
    'ALL',
    'Physics',
    'Chemistry',
    'Biology',
    'Computer Science',
    'Electronics',
    'Mechanical',
    'Civil',
    'Biotechnology'
  ];

  useEffect(() => {
    const loadEvents = async () => {
      setLoading(true);
      try {
        const [bk, ss, mn] = await Promise.all([
          DataService.getBookings(activeLab?.id),
          DataService.getPracticalSessions(activeLab?.id),
          DataService.getMaintenanceRecords(activeLab?.id)
        ]);
        setBookings(bk);
        setSessions(ss);
        setMaintenances(mn);
      } catch (err) {
        console.error('Failed to load schedule events:', err);
      } finally {
        setLoading(false);
      }
    };
    loadEvents();
  }, [activeLab]);

  // Aggregate and format all internal schedules
  const allEvents = [
    ...bookings.map(b => ({
      id: b.id,
      title: `${b.equipmentName} Workstation Reservation`,
      category: 'Equipment Booking',
      type: 'booking',
      discipline: 'Electronics',
      date: b.startTime.split('T')[0] || new Date().toISOString().split('T')[0],
      startTime: new Date(b.startTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      endTime: new Date(b.endTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      timeStr: `${new Date(b.startTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} - ${new Date(b.endTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`,
      user: b.userName,
      resource: b.equipmentName,
      labName: activeLab?.name || 'Advanced Materials & Sensors Lab',
      labType: 'Electronics / Engineering',
      status: b.status,
      badgeColor: 'bg-purple-100 text-purple-800 border-purple-200 dark:bg-purple-950/60 dark:text-purple-300'
    })),
    ...sessions.map(s => {
      let disc = 'Chemistry';
      if (s.title.toLowerCase().includes('data') || s.title.toLowerCase().includes('algorithm')) disc = 'Computer Science';
      else if (s.title.toLowerCase().includes('spectro') || s.title.toLowerCase().includes('titrat')) disc = 'Chemistry';
      else if (s.title.toLowerCase().includes('optics') || s.title.toLowerCase().includes('laser')) disc = 'Physics';
      else if (s.title.toLowerCase().includes('bio') || s.title.toLowerCase().includes('cell')) disc = 'Biotechnology';

      return {
        id: s.id,
        title: s.title,
        category: 'Practical Class',
        type: 'practical',
        discipline: disc,
        date: s.date || new Date().toISOString().split('T')[0],
        startTime: s.startTime,
        endTime: s.endTime,
        timeStr: `${s.startTime} - ${s.endTime}`,
        user: s.facultyName,
        resource: 'Bench Stations 01-12',
        labName: activeLab?.name || 'Central Science Facility',
        labType: disc,
        status: s.status,
        badgeColor: 'bg-blue-100 text-blue-800 border-blue-200 dark:bg-blue-950/60 dark:text-blue-300'
      };
    }),
    ...maintenances.map(m => ({
      id: m.id,
      title: `${m.equipmentName} Routine Calibration`,
      category: 'Maintenance & Calibration',
      type: 'maintenance',
      discipline: 'Mechanical',
      date: m.scheduledDate.split('T')[0],
      startTime: '09:00 AM',
      endTime: '11:30 AM',
      timeStr: '09:00 AM - 11:30 AM',
      user: m.technicianName,
      resource: m.equipmentName,
      labName: activeLab?.name || 'Precision Metrology Lab',
      labType: 'Mechanical / Physics',
      status: m.status,
      badgeColor: 'bg-amber-100 text-amber-800 border-amber-200 dark:bg-amber-950/60 dark:text-amber-300'
    }))
  ];

  // Filtering
  const filteredEvents = allEvents.filter(evt => {
    const matchesSearch =
      evt.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      evt.user.toLowerCase().includes(searchQuery.toLowerCase()) ||
      evt.resource.toLowerCase().includes(searchQuery.toLowerCase()) ||
      evt.labName.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesDiscipline =
      selectedDiscipline === 'ALL' || evt.discipline === selectedDiscipline;

    const matchesStatus =
      selectedStatus === 'ALL' || evt.status.toUpperCase() === selectedStatus.toUpperCase();

    const matchesEventType =
      selectedEventType === 'ALL' || evt.type === selectedEventType;

    return matchesSearch && matchesDiscipline && matchesStatus && matchesEventType;
  });

  const resetFilters = () => {
    setSearchQuery('');
    setSelectedDiscipline('ALL');
    setSelectedStatus('ALL');
    setSelectedEventType('ALL');
  };

  // Calendar calculations
  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const firstDayIndex = new Date(year, month, 1).getDay();

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const handlePrev = () => {
    if (viewMode === 'month') setCurrentDate(new Date(year, month - 1, 1));
    else if (viewMode === 'week') setCurrentDate(new Date(currentDate.getTime() - 7 * 86400000));
    else setCurrentDate(new Date(currentDate.getTime() - 86400000));
  };

  const handleNext = () => {
    if (viewMode === 'month') setCurrentDate(new Date(year, month + 1, 1));
    else if (viewMode === 'week') setCurrentDate(new Date(currentDate.getTime() + 7 * 86400000));
    else setCurrentDate(new Date(currentDate.getTime() + 86400000));
  };

  const exportICS = () => {
    let icsContent = "BEGIN:VCALENDAR\nVERSION:2.0\nPRODID:-//ILMS Multi-Lab Unified Schedule//EN\n";
    filteredEvents.forEach(evt => {
      icsContent += `BEGIN:VEVENT\nSUMMARY:${evt.title}\nDESCRIPTION:${evt.category} in ${evt.labName} (${evt.discipline})\nSTATUS:${evt.status}\nEND:VEVENT\n`;
    });
    icsContent += "END:VCALENDAR";

    const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `ilms-schedule-export-${new Date().toISOString().split('T')[0]}.ics`;
    link.click();
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Banner */}
      <div className="p-6 sm:p-8 bg-white border border-[#E4E7F0] rounded-3xl text-[#172033] shadow-card flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-3 py-1 rounded-full bg-cyan-50 text-cyan-800 border border-cyan-200 font-mono text-xs uppercase font-extrabold tracking-wider">
              ILMS Unified Schedule
            </span>
            <span className="text-[#5B6478] text-xs font-semibold">
              Timezone: {Intl.DateTimeFormat().resolvedOptions().timeZone}
            </span>
          </div>
          <h1 className="font-heading font-black text-2xl sm:text-4xl text-[#172033] mt-2">
            Schedule Planner & Timetable
          </h1>
          <p className="text-sm sm:text-base text-[#5B6478] mt-1 max-w-xl">
            Internal scheduling engine for academic practicals, faculty sessions, workstation bookings, and calibration appointments across all institutional laboratories.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={exportICS}
            className="px-4 py-2.5 rounded-2xl bg-[#F5F6FC] hover:bg-slate-100 text-[#172033] border border-[#E4E7F0] font-bold text-sm flex items-center gap-2 transition"
          >
            <Download className="w-4 h-4 text-[#172033]" />
            <span>Export Schedule (.ics)</span>
          </button>
        </div>
      </div>

      {/* Disciplinary Category Pills */}
      <div className="bg-white dark:bg-slate-900 border border-border dark:border-slate-800 rounded-2xl p-3 shadow-soft flex items-center gap-2 overflow-x-auto no-scrollbar">
        <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground px-2 flex items-center gap-1.5 shrink-0">
          <Layers className="w-3.5 h-3.5 text-purple-600" /> Disciplines:
        </span>
        {disciplines.map(disc => (
          <button
            key={disc}
            onClick={() => setSelectedDiscipline(disc)}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition shrink-0 ${
              selectedDiscipline === disc
                ? 'bg-gradient-to-r from-[#9333EA] to-[#4F7DFF] text-white shadow-sm'
                : 'bg-slate-100 dark:bg-slate-800 text-muted-foreground hover:text-foreground'
            }`}
          >
            {disc === 'ALL' ? 'All Disciplines' : disc}
          </button>
        ))}
        {selectedDiscipline !== 'ALL' && (
          <button
            onClick={() => setSelectedDiscipline('ALL')}
            className="text-xs text-rose-500 hover:underline px-2 shrink-0 flex items-center gap-1"
          >
            <X className="w-3 h-3" /> Clear
          </button>
        )}
      </div>

      {/* Filter and Controls Toolbar */}
      <div className="p-4 bg-white dark:bg-slate-900 border border-border dark:border-slate-800 rounded-3xl shadow-soft space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          {/* Date Navigator */}
          <div className="flex items-center space-x-3">
            <button
              onClick={handlePrev}
              className="p-2 rounded-xl border border-border dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
              title="Previous"
            >
              <ChevronLeft className="w-5 h-5 text-muted-foreground" />
            </button>
            <h2 className="font-heading font-black text-xl text-foreground dark:text-white min-w-[210px]">
              {monthNames[month]} {year}
            </h2>
            <button
              onClick={handleNext}
              className="p-2 rounded-xl border border-border dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
              title="Next"
            >
              <ChevronRight className="w-5 h-5 text-muted-foreground" />
            </button>
            <button
              onClick={() => setCurrentDate(new Date())}
              className="px-3.5 py-1.5 rounded-xl bg-purple-50 dark:bg-purple-950/40 text-purple-700 dark:text-purple-300 font-bold text-xs hover:bg-purple-100 transition"
            >
              Today
            </button>
          </div>

          {/* View Switcher: Month, Week, Day, Agenda */}
          <div className="flex items-center space-x-1.5 bg-slate-100 dark:bg-slate-800 p-1.5 rounded-2xl self-start sm:self-auto">
            {(['month', 'week', 'day', 'agenda'] as const).map(mode => (
              <button
                key={mode}
                onClick={() => setViewMode(mode)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold uppercase tracking-wider transition ${
                  viewMode === mode
                    ? 'bg-white dark:bg-slate-900 text-purple-700 dark:text-purple-400 shadow-sm'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                {mode}
              </button>
            ))}
          </div>
        </div>

        {/* Detailed Secondary Filters */}
        <div className="pt-2 border-t border-border dark:border-slate-800 flex flex-wrap items-center gap-3">
          <div className="relative flex-1 min-w-[220px]">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search practicals, faculty, equipment or room..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-slate-50 dark:bg-slate-800/60 border border-border dark:border-slate-700 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-purple-500/20"
            />
          </div>

          <div className="flex items-center gap-2">
            <select
              value={selectedEventType}
              onChange={e => setSelectedEventType(e.target.value)}
              className="px-3 py-2 bg-slate-50 dark:bg-slate-800/60 border border-border dark:border-slate-700 rounded-xl text-xs font-semibold focus:outline-none"
            >
              <option value="ALL">All Event Categories</option>
              <option value="practical">Practical Classes</option>
              <option value="booking">Equipment Reservations</option>
              <option value="maintenance">Maintenance & Calibration</option>
            </select>

            <select
              value={selectedStatus}
              onChange={e => setSelectedStatus(e.target.value)}
              className="px-3 py-2 bg-slate-50 dark:bg-slate-800/60 border border-border dark:border-slate-700 rounded-xl text-xs font-semibold focus:outline-none"
            >
              <option value="ALL">All Statuses</option>
              <option value="CONFIRMED">Confirmed / Active</option>
              <option value="PENDING">Pending Approval</option>
              <option value="COMPLETED">Completed</option>
            </select>

            {(searchQuery || selectedDiscipline !== 'ALL' || selectedEventType !== 'ALL' || selectedStatus !== 'ALL') && (
              <button
                onClick={resetFilters}
                className="px-3 py-2 rounded-xl text-xs font-bold text-rose-600 bg-rose-50 dark:bg-rose-950/30 hover:bg-rose-100 flex items-center gap-1 transition"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* MONTH VIEW GRID */}
      {viewMode === 'month' && (
        <div className="bg-white dark:bg-slate-900 border border-border dark:border-slate-800 rounded-3xl shadow-card overflow-hidden">
          {/* Day Headers */}
          <div className="grid grid-cols-7 border-b border-border dark:border-slate-800 text-center py-3 bg-slate-50 dark:bg-slate-800/60 text-xs font-bold uppercase tracking-wider text-muted-foreground">
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
              <div key={day}>{day}</div>
            ))}
          </div>

          {/* Month Cells */}
          <div className="grid grid-cols-7 auto-rows-fr divide-x divide-y divide-border dark:divide-slate-800">
            {Array.from({ length: firstDayIndex }).map((_, i) => (
              <div key={`empty-${i}`} className="min-h-[120px] bg-slate-50/40 dark:bg-slate-950/20 p-2" />
            ))}

            {Array.from({ length: daysInMonth }).map((_, i) => {
              const dayNum = i + 1;
              const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(dayNum).padStart(2, '0')}`;
              const dayEvents = filteredEvents.filter(e => e.date === dateStr);
              const isToday =
                new Date().getDate() === dayNum &&
                new Date().getMonth() === month &&
                new Date().getFullYear() === year;

              return (
                <div
                  key={dayNum}
                  className={`min-h-[130px] p-2 flex flex-col justify-between transition group hover:bg-purple-50/20 dark:hover:bg-slate-800/40 ${
                    isToday ? 'bg-purple-50/40 dark:bg-purple-950/20' : ''
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span
                      className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                        isToday
                          ? 'bg-purple-600 text-white font-extrabold shadow-sm'
                          : 'text-foreground dark:text-slate-200'
                      }`}
                    >
                      {dayNum}
                    </span>
                    {dayEvents.length > 0 && (
                      <span className="text-[10px] font-mono font-bold text-muted-foreground">
                        {dayEvents.length} event{dayEvents.length > 1 ? 's' : ''}
                      </span>
                    )}
                  </div>

                  {/* Day Events Preview */}
                  <div className="space-y-1.5 my-1.5 flex-1 overflow-y-auto max-h-[85px]">
                    {dayEvents.map(evt => (
                      <div
                        key={evt.id}
                        onClick={() => setSelectedEvent(evt)}
                        className={`p-1.5 rounded-lg border text-[11px] font-semibold cursor-pointer truncate transition hover:scale-[1.02] shadow-sm ${evt.badgeColor}`}
                      >
                        <div className="flex items-center space-x-1 truncate">
                          <span className="font-extrabold">{evt.startTime || evt.timeStr}</span>
                          <span className="truncate">{evt.title}</span>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="text-[10px] text-muted-foreground opacity-0 group-hover:opacity-100 transition">
                    Click to view
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* AGENDA / LIST VIEW */}
      {(viewMode === 'agenda' || viewMode === 'week' || viewMode === 'day') && (
        <div className="bg-white dark:bg-slate-900 border border-border dark:border-slate-800 rounded-3xl shadow-card overflow-hidden divide-y divide-border dark:divide-slate-800">
          <div className="p-4 bg-slate-50 dark:bg-slate-800/60 font-heading font-extrabold text-sm text-foreground flex items-center justify-between">
            <span>Scheduled Institutional Sessions & Bookings ({filteredEvents.length})</span>
            <span className="text-xs text-muted-foreground font-normal">Sorted chronologically</span>
          </div>

          {filteredEvents.length === 0 ? (
            <div className="p-12 text-center text-muted-foreground">
              <CalendarIcon className="w-10 h-10 mx-auto text-slate-300 dark:text-slate-700 mb-3" />
              <p className="font-bold text-base text-foreground dark:text-white">No Scheduled Events Found</p>
              <p className="text-xs mt-1">Try resetting filters or changing the active laboratory selection.</p>
            </div>
          ) : (
            filteredEvents.map(evt => (
              <div
                key={evt.id}
                onClick={() => setSelectedEvent(evt)}
                className="p-4 sm:p-5 hover:bg-slate-50/80 dark:hover:bg-slate-800/40 cursor-pointer transition flex flex-col sm:flex-row sm:items-center justify-between gap-4"
              >
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 rounded-2xl bg-purple-50 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 flex flex-col items-center justify-center font-bold shrink-0">
                    <span className="text-xs uppercase">{new Date(evt.date).toLocaleDateString([], { month: 'short' })}</span>
                    <span className="text-base font-black leading-none">{new Date(evt.date).getDate()}</span>
                  </div>

                  <div>
                    <div className="flex items-center space-x-2">
                      <h4 className="font-heading font-extrabold text-sm sm:text-base text-foreground dark:text-white">
                        {evt.title}
                      </h4>
                      <span className={`text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full border ${evt.badgeColor}`}>
                        {evt.category}
                      </span>
                      <span className="text-[10px] font-mono px-2 py-0.5 bg-slate-100 dark:bg-slate-800 rounded text-muted-foreground">
                        {evt.discipline}
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center gap-y-1 gap-x-4 text-xs text-muted-foreground mt-1.5">
                      <span className="flex items-center gap-1 font-semibold text-foreground dark:text-slate-200">
                        <Clock className="w-3.5 h-3.5 text-purple-600" /> {evt.timeStr}
                      </span>
                      <span className="flex items-center gap-1">
                        <Building2 className="w-3.5 h-3.5" /> {evt.labName}
                      </span>
                      <span className="flex items-center gap-1">
                        <Users className="w-3.5 h-3.5" /> Lead: {evt.user}
                      </span>
                      <span className="flex items-center gap-1">
                        <Cpu className="w-3.5 h-3.5" /> Resource: {evt.resource}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-2 shrink-0 self-end sm:self-center">
                  <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-50 text-emerald-700 border border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300">
                    {evt.status}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* EVENT DETAILS MODAL */}
      {selectedEvent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 border border-border dark:border-slate-800 rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden flex flex-col">
            <div className="p-6 bg-gradient-to-r from-purple-700 to-indigo-600 text-white flex items-center justify-between">
              <div>
                <span className="text-[11px] uppercase tracking-wider font-extrabold bg-white/20 px-2.5 py-0.5 rounded-full">
                  {selectedEvent.category} • {selectedEvent.discipline}
                </span>
                <h3 className="font-heading font-black text-xl text-white mt-1">
                  {selectedEvent.title}
                </h3>
              </div>
              <button
                onClick={() => setSelectedEvent(null)}
                className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3 p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-border dark:border-slate-800">
                <div>
                  <span className="text-muted-foreground block text-[10px] uppercase font-bold">Scheduled Date</span>
                  <span className="font-extrabold text-sm text-foreground dark:text-white">{selectedEvent.date}</span>
                </div>
                <div>
                  <span className="text-muted-foreground block text-[10px] uppercase font-bold">Session Timing</span>
                  <span className="font-extrabold text-sm text-foreground dark:text-white">{selectedEvent.timeStr}</span>
                </div>
                <div>
                  <span className="text-muted-foreground block text-[10px] uppercase font-bold">Facility Location</span>
                  <span className="font-bold text-foreground dark:text-white">{selectedEvent.labName}</span>
                </div>
                <div>
                  <span className="text-muted-foreground block text-[10px] uppercase font-bold">Assigned Equipment</span>
                  <span className="font-bold text-foreground dark:text-white">{selectedEvent.resource}</span>
                </div>
              </div>

              <div className="space-y-1">
                <span className="text-muted-foreground block text-[10px] uppercase font-bold">Responsible Person / In-Charge</span>
                <p className="font-semibold text-foreground dark:text-white text-sm">{selectedEvent.user}</p>
              </div>

              <div className="space-y-1">
                <span className="text-muted-foreground block text-[10px] uppercase font-bold">Operational Status</span>
                <span className="inline-block px-3 py-1 rounded-full text-xs font-bold bg-purple-50 text-purple-700 border border-purple-200 dark:bg-purple-950/40 dark:text-purple-300">
                  {selectedEvent.status}
                </span>
              </div>

              <div className="pt-4 border-t border-border dark:border-slate-800 flex justify-end space-x-2">
                <button
                  onClick={() => setSelectedEvent(null)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-foreground dark:text-white rounded-xl font-bold"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
