import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Menu,
  Bell,
  Download,
  WifiOff,
  Building2,
  QrCode,
  LogOut,
  ChevronDown,
  Sparkles,
  Search,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Cpu,
  Layers,
  User,
  Settings,
  Shield,
  Sliders
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { usePWA } from '../hooks/usePWA';
import { InAppNotification, Laboratory } from '../types';
import { DataService } from '../services/dataService';

interface NavbarProps {
  onToggleSidebar: () => void;
  onOpenQRScanner: () => void;
  onOpenCommandPalette: () => void;
  onOpenOnboarding?: () => void;
  notifications: InAppNotification[];
  onRefreshNotifications: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onToggleSidebar,
  onOpenQRScanner,
  onOpenCommandPalette,
  onOpenOnboarding,
  notifications,
  onRefreshNotifications,
}) => {
  const navigate = useNavigate();
  const {
    currentUser,
    activeLab,
    laboratories,
    allUsers,
    switchUser,
    switchLaboratory,
    logout,
    isFirebaseActive
  } = useAuth();

  const { isOnline, isInstallable, promptInstall } = usePWA();
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showLabMenu, setShowLabMenu] = useState(false);
  const [showNotifMenu, setShowNotifMenu] = useState(false);
  const [labSearchQuery, setLabSearchQuery] = useState('');

  const unreadCount = notifications.filter(n => !n.read).length;

  const handleMarkAsRead = async (id: string) => {
    await DataService.markNotificationRead(id);
    onRefreshNotifications();
  };

  // Filter laboratories by authorization & search query
  const authorizedLabs = laboratories.filter(lab => {
    if (currentUser.role === 'admin') return true;
    if (currentUser.assignedLabs && currentUser.assignedLabs.length > 0) {
      return currentUser.assignedLabs.includes(lab.id);
    }
    // Default fallback: allow assigned or all if none specified
    return true;
  });

  const searchedLabs = authorizedLabs.filter(lab =>
    lab.name.toLowerCase().includes(labSearchQuery.toLowerCase()) ||
    lab.code.toLowerCase().includes(labSearchQuery.toLowerCase()) ||
    lab.type.toLowerCase().includes(labSearchQuery.toLowerCase()) ||
    lab.building.toLowerCase().includes(labSearchQuery.toLowerCase())
  );

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-[#E9DDF1] text-[#332B40] shadow-sm transition-colors no-print">
      <div className="px-4 sm:px-6 py-2.5 flex items-center justify-between gap-2 sm:gap-4">
        {/* LEFT: Mobile hamburger & ILMS Academic Branding */}
        <div className="flex items-center space-x-2.5 sm:space-x-3 shrink-0">
          <button
            onClick={onToggleSidebar}
            className="p-2 text-[#71667D] hover:text-[#332B40] rounded-xl hover:bg-[#FFF8F2] lg:hidden transition"
            aria-label="Toggle navigation menu"
          >
            <Menu className="w-5 h-5" />
          </button>

          {/* Brand Logo with Lavender-Peach Gradient */}
          <div className="flex items-center space-x-2.5 cursor-pointer" onClick={() => navigate('/')}>
            <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-[#BCA0F5] to-[#FFD2BF] flex items-center justify-center shadow-sm">
              <span className="font-extrabold text-sm tracking-wider text-white">ILMS</span>
            </div>
            <div className="hidden sm:block">
              <div className="flex items-center space-x-1.5">
                <span className="font-heading font-black text-base text-[#332B40] tracking-tight">
                  ILMS
                </span>
                <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-[#F0E9FF] text-[#8961D8] border border-[#BCA0F5]/40">
                  Lab OS
                </span>
              </div>
              <p className="text-[10px] font-semibold text-[#71667D] leading-none">
                Intelligent University Management
              </p>
            </div>
          </div>
        </div>

        {/* MIDDLE: GLOBAL SEARCH BAR (Responsive on Phones) */}
        <div className="flex-1 max-w-2xl mx-1.5 sm:mx-6">
          <button
            onClick={onOpenCommandPalette}
            className="w-full flex items-center justify-between px-2.5 sm:px-4 py-2 sm:py-2.5 rounded-2xl bg-[#FFF8F2] border border-[#E9DDF1] hover:border-[#BCA0F5] text-[#71667D] text-xs sm:text-sm transition group shadow-inner"
          >
            <div className="flex items-center space-x-2 truncate">
              <Search className="w-4 h-4 text-[#8961D8] shrink-0 group-hover:scale-110 transition" />
              <span className="truncate text-left hidden sm:inline">Search laboratories, equipment, inventory, faculty...</span>
              <span className="truncate text-left inline sm:hidden">Search...</span>
            </div>
            <kbd className="hidden md:inline-flex items-center px-2 py-0.5 text-[10px] font-mono font-bold bg-white border border-[#E9DDF1] rounded-lg text-[#71667D] shadow-sm shrink-0">
              Ctrl+K
            </kbd>
          </button>
        </div>

        {/* RIGHT: Top-Right Lab Selector, QR Scan, Notifications, User Profile */}
        <div className="flex items-center space-x-2 sm:space-x-3 shrink-0">
          {/* Quick QR Scanner Shortcut */}
          <button
            onClick={onOpenQRScanner}
            title="Scan QR Code / Barcode"
            className="hidden sm:flex items-center space-x-1.5 px-3 py-2 rounded-2xl bg-[#F0E9FF] border border-[#BCA0F5]/50 text-[#8961D8] hover:bg-[#BCA0F5] hover:text-white text-xs font-semibold transition shadow-sm"
          >
            <QrCode className="w-4 h-4" />
            <span className="hidden md:inline">Scan QR</span>
          </button>

          {/* PWA Install Button (if eligible) */}
          {isInstallable && (
            <button
              onClick={promptInstall}
              title="Install ILMS as PWA App"
              className="flex items-center space-x-1.5 px-3 py-2 rounded-2xl bg-[#FFF8F2] border border-[#E9DDF1] text-[#332B40] hover:bg-[#F0E9FF] text-xs font-semibold transition"
            >
              <Download className="w-3.5 h-3.5 text-[#8961D8]" />
              <span className="hidden lg:inline">Install App</span>
            </button>
          )}

          {/* TOP-RIGHT LABORATORY SELECTOR */}
          <div className="relative">
            <button
              onClick={() => {
                setShowLabMenu(!showLabMenu);
                setShowUserMenu(false);
                setShowNotifMenu(false);
              }}
              className="flex items-center space-x-2.5 px-3.5 py-2 rounded-2xl bg-[#FFF8F2] hover:bg-[#F0E9FF] border border-[#E9DDF1] hover:border-[#BCA0F5] transition text-sm font-semibold text-[#332B40] shadow-sm"
            >
              <div className="w-6 h-6 rounded-lg bg-[#8961D8] text-white flex items-center justify-center shrink-0 shadow-sm">
                <Building2 className="w-3.5 h-3.5" />
              </div>
              <div className="text-left max-w-[80px] sm:max-w-[180px] truncate">
                <span className="text-[9px] sm:text-[10px] text-[#71667D] block uppercase font-bold tracking-wider leading-none">
                  Active Lab
                </span>
                <span className="font-heading font-bold text-xs sm:text-sm text-[#332B40] truncate block">
                  {activeLab ? activeLab.name : 'Select Lab'}
                </span>
              </div>
              <ChevronDown className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-[#8961D8] ml-0.5 shrink-0" />
            </button>

            {/* Rich Searchable Laboratory Cards Popover — Responsive on Phones */}
            {showLabMenu && (
              <div className="fixed sm:absolute right-2 sm:right-0 mt-2.5 w-[calc(100vw-16px)] sm:w-96 max-w-md bg-white dark:bg-slate-900 border border-[#E9DDF1] dark:border-slate-800 rounded-3xl shadow-2xl py-3 z-50 animate-in fade-in slide-in-from-top-2">
                <div className="px-4 pb-2 border-b border-border dark:border-slate-800">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
                      Authorized Laboratories ({authorizedLabs.length})
                    </span>
                    <span className="text-[11px] font-semibold text-purple-600 dark:text-purple-400">
                      Role: {currentUser.role}
                    </span>
                  </div>
                  {/* Search Filter Inside Dropdown */}
                  <div className="relative">
                    <Search className="w-3.5 h-3.5 text-muted-foreground absolute left-3 top-2.5" />
                    <input
                      type="text"
                      value={labSearchQuery}
                      onChange={e => setLabSearchQuery(e.target.value)}
                      placeholder="Search facility name or code..."
                      className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-border dark:border-slate-700 rounded-xl focus:outline-none focus:ring-1 focus:ring-purple-500"
                    />
                  </div>
                </div>

                <div className="max-h-80 overflow-y-auto px-2 py-2 space-y-1.5">
                  {searchedLabs.length === 0 ? (
                    <div className="p-4 text-center text-xs text-muted-foreground">
                      No matching laboratories found.
                    </div>
                  ) : (
                    searchedLabs.map((lab: Laboratory) => {
                      const isCurrent = activeLab?.id === lab.id;
                      return (
                        <button
                          key={lab.id}
                          onClick={() => {
                            switchLaboratory(lab.id);
                            setShowLabMenu(false);
                          }}
                          className={`w-full text-left p-3 rounded-2xl transition border ${
                            isCurrent
                              ? 'bg-purple-50/80 dark:bg-purple-950/40 border-purple-300 dark:border-purple-600 text-purple-950 dark:text-purple-100 shadow-sm'
                              : 'hover:bg-slate-50 dark:hover:bg-slate-800 border-transparent text-foreground dark:text-slate-200'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-sm text-foreground dark:text-white flex items-center gap-1.5">
                              {lab.name}
                              {isCurrent && (
                                <CheckCircle2 className="w-4 h-4 text-purple-600 inline" />
                              )}
                            </span>
                            <span className="text-[11px] px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 font-mono font-bold text-muted-foreground border border-border dark:border-slate-700">
                              {lab.code}
                            </span>
                          </div>
                          <div className="text-xs text-muted-foreground flex items-center gap-2 mt-1">
                            <span>{lab.building} ({lab.roomNumber})</span>
                            <span>•</span>
                            <span className="capitalize">{lab.type.replace('_', ' ')}</span>
                            <span>•</span>
                            <span className="text-emerald-600 font-medium">Active</span>
                          </div>
                        </button>
                      );
                    })
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Notifications Bell */}
          <div className="relative">
            <button
              onClick={() => {
                setShowNotifMenu(!showNotifMenu);
                setShowUserMenu(false);
                setShowLabMenu(false);
              }}
              className="p-2.5 rounded-2xl text-muted-foreground hover:text-foreground hover:bg-slate-100 dark:hover:bg-slate-800 relative transition"
              aria-label="Notifications"
            >
              <Bell className="w-5 h-5" />
              {unreadCount > 0 && (
                <span className="absolute top-1.5 right-1.5 w-4 h-4 rounded-full bg-rose-500 text-[10px] font-bold text-white flex items-center justify-center shadow-sm">
                  {unreadCount}
                </span>
              )}
            </button>

            {showNotifMenu && (
              <div className="fixed sm:absolute right-2 sm:right-0 mt-2.5 w-[calc(100vw-16px)] sm:w-96 max-w-md bg-white dark:bg-slate-900 border border-[#E9DDF1] dark:border-slate-800 rounded-3xl shadow-2xl py-3 z-50 animate-in fade-in slide-in-from-top-2">
                <div className="px-4 pb-2 border-b border-border dark:border-slate-800 flex items-center justify-between text-xs font-bold text-foreground dark:text-slate-200">
                  <span className="uppercase tracking-wider text-muted-foreground">Notifications</span>
                  <span className="text-purple-600 font-semibold">{unreadCount} unread</span>
                </div>
                <div className="max-h-72 overflow-y-auto divide-y divide-border/50 dark:divide-slate-800">
                  {notifications.length === 0 ? (
                    <div className="p-6 text-center text-xs text-muted-foreground">
                      No new notifications for your assigned role.
                    </div>
                  ) : (
                    notifications.map(n => (
                      <div
                        key={n.id}
                        onClick={() => handleMarkAsRead(n.id)}
                        className={`p-3.5 text-xs cursor-pointer transition ${
                          n.read ? 'bg-transparent text-muted-foreground' : 'bg-purple-50/40 dark:bg-purple-950/20 text-foreground dark:text-slate-100'
                        }`}
                      >
                        <div className="flex items-center justify-between font-semibold">
                          <span className="text-sm font-bold text-foreground dark:text-white">{n.title}</span>
                          <span className="text-[10px] text-muted-foreground">{new Date(n.createdAt).toLocaleDateString()}</span>
                        </div>
                        <p className="text-xs text-muted-foreground mt-1 leading-relaxed">{n.message}</p>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>

          {/* User Profile & Demo Role Switcher */}
          <div className="relative">
            <button
              onClick={() => {
                setShowUserMenu(!showUserMenu);
                setShowLabMenu(false);
                setShowNotifMenu(false);
              }}
              className="flex items-center space-x-2.5 p-1.5 sm:px-3 sm:py-2 rounded-2xl bg-slate-100/80 dark:bg-slate-800 border border-border dark:border-slate-700 hover:border-purple-400 transition"
            >
              <div className="w-8 h-8 rounded-xl bg-cyan-50 text-cyan-800 border border-cyan-200 flex items-center justify-center font-bold text-sm shadow-sm">
                {currentUser.displayName ? currentUser.displayName.charAt(0) : 'U'}
              </div>
              <div className="hidden lg:block text-left">
                <span className="text-sm font-bold text-[#172033] block leading-none">
                  {currentUser.displayName.split(' ')[0]}
                </span>
                <span className="text-[10px] font-bold text-cyan-700 uppercase tracking-wider block mt-0.5">
                  {currentUser.role}
                </span>
              </div>
              <ChevronDown className="w-4 h-4 text-muted-foreground hidden sm:block" />
            </button>

            {showUserMenu && (
              <div className="fixed sm:absolute right-2 sm:right-0 mt-2.5 w-[calc(100vw-16px)] sm:w-84 max-w-sm bg-white border border-[#E4E7F0] rounded-3xl shadow-2xl py-3 z-50 animate-in fade-in slide-in-from-top-2">
                <div className="px-4 py-2 border-b border-[#E4E7F0]">
                  <p className="text-sm font-bold text-[#172033]">{currentUser.displayName}</p>
                  <p className="text-xs text-[#5B6478] truncate">{currentUser.email}</p>
                  <div className="mt-2 flex items-center space-x-2">
                    <span className="text-[11px] px-2.5 py-0.5 rounded-full bg-cyan-50 text-cyan-800 border border-cyan-200 font-bold uppercase tracking-wider">
                      {currentUser.role}
                    </span>
                    <span className="text-[11px] text-[#5B6478]">ID: {currentUser.id}</span>
                  </div>
                </div>

                <div className="py-1.5 space-y-0.5">
                  <button
                    onClick={() => {
                      navigate('/settings');
                      setShowUserMenu(false);
                    }}
                    className="w-full text-left px-4 py-2 text-xs font-semibold text-foreground dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-[#141E34] flex items-center space-x-2.5 transition"
                  >
                    <User className="w-4 h-4 text-cyan" />
                    <span>My Profile</span>
                  </button>

                  <button
                    onClick={() => {
                      navigate('/settings');
                      setShowUserMenu(false);
                    }}
                    className="w-full text-left px-4 py-2 text-xs font-semibold text-foreground dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-[#141E34] flex items-center space-x-2.5 transition"
                  >
                    <Settings className="w-4 h-4 text-cyan" />
                    <span>Account Settings</span>
                  </button>

                  <button
                    onClick={() => {
                      navigate('/settings');
                      setShowUserMenu(false);
                    }}
                    className="w-full text-left px-4 py-2 text-xs font-semibold text-foreground dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-[#141E34] flex items-center space-x-2.5 transition"
                  >
                    <Bell className="w-4 h-4 text-cyan" />
                    <span>Notification Preferences</span>
                  </button>

                  <button
                    onClick={() => {
                      navigate('/settings');
                      setShowUserMenu(false);
                    }}
                    className="w-full text-left px-4 py-2 text-xs font-semibold text-foreground dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-[#141E34] flex items-center space-x-2.5 transition"
                  >
                    <Shield className="w-4 h-4 text-cyan" />
                    <span>Security and Password</span>
                  </button>

                  <button
                    onClick={() => {
                      navigate('/laboratories');
                      setShowUserMenu(false);
                    }}
                    className="w-full text-left px-4 py-2 text-xs font-semibold text-foreground dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-[#141E34] flex items-center space-x-2.5 transition"
                  >
                    <Building2 className="w-4 h-4 text-cyan" />
                    <span>Assigned Laboratories</span>
                  </button>

                  {onOpenOnboarding && (
                    <button
                      onClick={() => {
                        onOpenOnboarding();
                        setShowUserMenu(false);
                      }}
                      className="w-full text-left px-4 py-2 text-xs font-semibold text-purple-600 hover:bg-purple-50 dark:hover:bg-purple-950/30 flex items-center space-x-2.5 transition"
                    >
                      <HelpCircle className="w-4 h-4 text-purple-600" />
                      <span>Help and Support (Tour)</span>
                    </button>
                  )}
                </div>

                <div className="border-t border-border dark:border-slate-800 mt-1 pt-1.5 px-2">
                  <button
                    onClick={() => {
                      logout();
                      setShowUserMenu(false);
                      navigate('/login');
                    }}
                    className="w-full text-left px-3 py-2 rounded-xl text-xs text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30 font-bold flex items-center space-x-2.5 transition"
                  >
                    <LogOut className="w-4 h-4" />
                    <span>Sign Out</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
